
# Exon

 Exon provides a multitude of user-friendly commands, including full slash command functionality and buttons, dropdowns, message commands and forms.


## Links

 - [Website](https://sites.google.com/view/exon-bot)
 - [Invite to server](https://discord.com/oauth2/authorize?client_id=931158201779486730&permissions=1644972474359&scope=bot%20applications.commands)
 - [Help Server](https://discord.gg/invite/54DTY7hv)


## Authors

- [@Tom Sumner](https://www.github.com/Tom-Sumner)
- [@Maciej-JS](https://github.com/Maciej-JS)


#### Thanks To
- [Sinkez Hosting](https://hosting.sinkezstudios.com)


### License
[![MIT License](https://img.shields.io/apm/l/atomic-design-ui.svg?)](https://github.com/tterb/atomic-design-ui/blob/master/LICENSEs)

